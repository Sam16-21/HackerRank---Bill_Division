#include <iostream>
#include <stdlib.h>
#include <vector>
#include <algorithm>

using namespace std;

//It should print Bon Appetit if the bill is fairly split, where Anna 
//chooses a meal in the array she won't tak, Otherwise, it should print the integer amount of money that Brian owes Anna.
//bonAppetit has the following parameter(s):
//bill: an array of integers representing the cost of each item ordered
//k: an integer representing the zero-based index of the item Anna doesn't eat
//b: the amount of money that Anna contributed to the bill

void bonAppetit(vector<int>& bill, int& k, int& b) {
    uint64_t actualSum = 0;

    //Check and remove what Anna rejected
    for (uint64_t i = 0; i < bill.size(); i++) {
        if (bill[i] == bill[k]) {
            bill.erase(bill.begin() + k);
        }
    }
    //Sums and Calculates average of the rest
    for (uint64_t a = 0; a < bill.size(); a++) {
        actualSum += bill[a];
    }
    actualSum /= 2;

    //Checks if Anna was Overcharged or rightly charged
    if (b == actualSum) {
        cout << "Bon Appetit";

    }
    else if (b > actualSum) {
        cout << b - actualSum;
    }
}

void BonAppetit(vector<int>& bill, int& k, int& b) {
    int sum = 0;
    for (int& item : bill) {
        sum += item;
    }
    int mustPay = (sum - bill[k]) / 2;

    if (mustPay <= b) {
        cout << "Bon Appetit";
    }
    else {
        cout << b - mustPay << endl;
    }
}

int main() {
    int menuSize;
    cout << "Enter the menu size: ";
    cin >> menuSize;

    vector<int> menu(menuSize);
    cout << "\nEnter integer items on menu: ";
    for (int i = 0; i < menuSize; i++) {
        cin >> menu[i];
    }

    int annaPayment;
    cout << "\nEnter what she was charged: ";
    cin >> annaPayment;

    int rejectedItem;
    cout << "\nEnter the unwanted item index from the list: ";
    cin >> rejectedItem;

    bonAppetit(menu, rejectedItem, annaPayment);

    system("pause>nul");
}
